EIGHT-MODULE ELECTRO-EXOCYTOSIS STORYBOARDS

Five comparisons, each with three scenario rows and eight module columns.
Each panel contains one representative readout. All five figures share the
same scales for each readout. Input labels refer to the displayed readout,
not every possible connection in the complete framework.

THE FIVE COMPARISONS

1. Lower-exposure, secretory and injury examples. These reuse the original
   illustrative scenarios, which change both exposure and biological settings.
2. Pulse number: 5, 20 and 80 pulses, with the other settings held fixed.
3. Calcium removal: low, reference and high transport capacity. SERCA, PMCA
   and NCX capacities change together by 0.25x, 1x and 2x.
4. EV machinery: Rab conversion, ESCRT and Rab docking baselines change
   together by 0.25x, 1x and 2x. The basal small-EV release rate is unchanged.
5. Isolation: 10%, 30% and 60% recovery, with the biological settings fixed.

WHAT EACH COLUMN SHOWS

1. Deposited electrical energy, J/mL (bar).
2. Reduced plasma-membrane voltage, V (bar).
3. Cytosolic calcium, micromolar, during the first minute (curve).
4. Repair-associated activation, a 0-1 score, during the first minute (curve).
5. Cumulative small-EV release over 30 minutes, relative model units (curve).
6. Protein cargo enrichment at 30 minutes, a model score (bar).
7. Viability score from peak simulated damage, percent (bar).
8. Recovered small-EV output at 30 minutes, relative model units (bar).

HOW TO READ THE RESULTS

Read across a row to follow one scenario through the framework. Compare down
a column to see which part changes. Identical upstream panels are intentional:
they show that an intervention acts later in the model. The isolation study
is an explicit negative control: columns 1-7 are identical and recovered yield
changes in the ratio 1:3:6.

These are unfitted, illustrative simulations with provisional parameters.
They do not establish an optimal exposure, a validated response in a particular
cell type, absolute particle counts, measured protein cargo, or EV function.
Heating is diagnostic and does not drive injury in this implementation.
The repair-activation score does not dynamically close pores or repair damage.
The manufacturing readout applies an assumed recovery factor to cumulative
small-EV release. It does not harvest the separate extracellular-medium stock.
Other manufacturing scores use cargo and quality, but this recovered-yield
readout depends on release and recovery alone.

FILES

figures/: five 600-dpi PNGs and five vector SVGs. The intended figure size is
17.78 by 6.4 inches for a presentation. Use at full width. These are not
7.1-inch double-column manuscript layouts.

manifest.json: plotting arrays, complete scenario definitions, parameter
overrides, captions, speaker scripts, readout definitions and source hashes.

storyboard_summary.csv: results for all 15 runs.
timeseries/: full 0.25-second output grid over 30 minutes for selected states.
scenarios/: exact scenario inputs.
snapshots/: resolved model parameters and endpoint diagnostics for each run.

The downloadable archive also includes captions.txt, speaker_script.txt and
the Python source needed for this figure generator under code/. Optional
3D visualization assets are not included because these studies do not use them.

REGENERATION

With this project's Python dependencies installed, run from the repository root
(or from the code/ directory in the archive):

  python -m examples.storyboard_eight_modules --out results/eight_module_storyboards

Focused checks:

  python -m pytest tests/test_eight_module_storyboards.py -q

The three focused checks cover complete output generation and figure export,
the isolation negative control, and the expected ordering of calcium-clearance
durations and viability scores. They passed for this export.

The editable PowerPoint charts use the same plotting data, rounded to 12
significant figures for portable embedded Excel data. The CSVs and manifest
retain full simulation precision. The native slides leave a small margin
beyond the last time tick so labels remain visible.
